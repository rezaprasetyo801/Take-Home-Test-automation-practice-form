import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.model.FailureHandling as FailureHandling


WebUI.openBrowser('')
WebUI.navigateToUrl('https://demoqa.com/automation-practice-form')

WebUI.setText(findTestObject('Object Repository/DemoQA Automation Practice Form/input_firstname'), firstName)
WebUI.setText(findTestObject('Object Repository/DemoQA Automation Practice Form/input_lastname'), lastName)
WebUI.setText(findTestObject('Object Repository/DemoQA Automation Practice Form/input_email'), email)


if (gender == 'Male') {
	WebUI.click(findTestObject('Object Repository/DemoQA Automation Practice Form/radio_male'))
		
	}

WebUI.setText(findTestObject('Object Repository/DemoQA Automation Practice Form/input_mobile'), mobile)

WebUI.click(findTestObject('Object Repository/DemoQA Automation Practice Form/button_submit'))

// Assertion
if (expectedResult == 'SUCCESS') {
	WebUI.verifyElementPresent(findTestObject('popup_success'), 5)
} else {
	WebUI.verifyElementPresent(findTestObject('validation_error'), 5)
}

WebUI.closeBrowser()
